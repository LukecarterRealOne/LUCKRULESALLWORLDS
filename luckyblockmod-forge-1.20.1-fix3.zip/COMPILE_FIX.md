# Forge 1.20.1 compiler fixes

Applied from the latest GitHub Actions error log:

1. Replaced the five direct `Abilities.flyingSpeed` field reads/writes with `getFlyingSpeed()` and `setFlyingSpeed(float)`.
2. Cast the nullable entity parameter in `sw.getEntities((Entity) null, ...)` to disambiguate the overload.
3. Added an `Fx.sound(..., Holder<SoundEvent>, ...)` overload that unwraps the holder with `value()` while retaining the existing direct `SoundEvent` overload.

The warnings about deprecated APIs are not compilation errors. A full build still needs to be run by Gradle/GitHub Actions to confirm there are no remaining errors.

## Fix 3 — Java lambda capture

The Lightning Storm scheduled callback no longer reads the changing loop variable `i` from inside a lambda. The per-strike screen-flash condition is captured in the final local variable `screenFlashThisStrike` before scheduling the callback. This fixes the Java error `local variables referenced from a lambda expression must be final or effectively final` reported at `LuckyBlockItem.java` around line 451.
