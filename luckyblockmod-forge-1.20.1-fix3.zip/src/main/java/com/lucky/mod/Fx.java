package com.lucky.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

public class Fx {
    /** Global safety caps keep dramatic abilities readable instead of filling every client's screen. */
    private static final int MAX_BURST_PARTICLES = 24;
    private static final int MAX_RING_POINTS = 18;
    private static final int MAX_WORLD_PARTICLE_CALLS_PER_TICK = 160;
    private static final int MAX_WORLD_PARTICLES_PER_TICK = 350;
    private static final Map<ServerLevel, ParticleBudget> PARTICLE_BUDGETS = new WeakHashMap<>();
    private static final Map<UUID, Long> LAST_SCREEN_TICK = new HashMap<>();
    private static long lastScreenCleanupTick = Long.MIN_VALUE;

    private static final class ParticleBudget {
        private long tick = Long.MIN_VALUE;
        private int calls;
        private int particles;

        private void resetIfNeeded(long currentTick) {
            if (tick != currentTick) {
                tick = currentTick;
                calls = 0;
                particles = 0;
            }
        }
    }

    /** Particles visible from far away (normal particle spawning only reaches ~32 blocks). */
    public static void burst(ServerLevel sw, ParticleOptions particle, double x, double y, double z,
                             int count, double dx, double dy, double dz, double speed) {
        int requested = Math.max(0, Math.min(count, MAX_BURST_PARTICLES));
        if (requested == 0) return;

        boolean hasViewer = false;
        for (ServerPlayer player : sw.players()) {
            if (player.distanceToSqr(x, y, z) < 160 * 160) {
                hasViewer = true;
                break;
            }
        }
        if (!hasViewer) return;

        // Every ring point is a separate burst call. A per-dimension tick budget stops
        // several simultaneous abilities from flooding clients with thousands of packets.
        int safeCount;
        synchronized (PARTICLE_BUDGETS) {
            ParticleBudget budget = PARTICLE_BUDGETS.computeIfAbsent(sw, ignored -> new ParticleBudget());
            budget.resetIfNeeded(sw.getGameTime());
            if (budget.calls >= MAX_WORLD_PARTICLE_CALLS_PER_TICK
                    || budget.particles >= MAX_WORLD_PARTICLES_PER_TICK) return;
            safeCount = Math.min(requested, MAX_WORLD_PARTICLES_PER_TICK - budget.particles);
            budget.calls++;
            budget.particles += safeCount;
        }
        for (ServerPlayer player : sw.players()) {
            if (player.distanceToSqr(x, y, z) < 160 * 160) {
                sw.sendParticles(player, particle, true, x, y, z, safeCount, dx, dy, dz, speed);
            }
        }
    }

    /** Points are capped to avoid generating hundreds of separate packets per ring. */
    public static void ring(ServerLevel sw, ParticleOptions particle, double cx, double cy, double cz, double radius, int points) {
        int safePoints = Math.max(8, Math.min(points, MAX_RING_POINTS));
        for (int i = 0; i < safePoints; i++) {
            double angle = Math.PI * 2 * i / safePoints;
            burst(sw, particle, cx + Math.cos(angle) * radius, cy, cz + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
        }
    }

    /** An open arc reads as a guard/parry, unlike the full rings used by burst abilities. */
    public static void arc(ServerLevel sw, ParticleOptions particle, double cx, double cy, double cz,
                           double radius, double startAngle, double angleSpan, int points) {
        int safePoints = Math.max(6, Math.min(points, MAX_RING_POINTS));
        for (int i = 0; i <= safePoints; i++) {
            double angle = startAngle + angleSpan * i / safePoints;
            burst(sw, particle, cx + Math.cos(angle) * radius, cy, cz + Math.sin(angle) * radius,
                    1, 0, 0, 0, 0);
        }
    }

    /** Sparse particle line used for rifts and ability trails. */
    public static void line(ServerLevel sw, ParticleOptions particle,
                            double x1, double y1, double z1, double x2, double y2, double z2, int points) {
        int safePoints = Math.max(2, Math.min(points, 18));
        for (int i = 0; i <= safePoints; i++) {
            double t = i / (double) safePoints;
            burst(sw, particle,
                    x1 + (x2 - x1) * t,
                    y1 + (y2 - y1) * t,
                    z1 + (z2 - z1) * t,
                    1, 0, 0, 0, 0);
        }
    }

    /** Render a rotating wireframe cube, with only four particles per edge by default. */
    public static void cubeOutline(ServerLevel sw, ParticleOptions particle, double cx, double cy, double cz,
                                   double halfSize, double yaw, int pointsPerEdge) {
        int steps = Math.max(2, Math.min(pointsPerEdge, 6));
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double[][] vertices = new double[8][3];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? -halfSize : halfSize;
            double y = (i & 2) == 0 ? -halfSize : halfSize;
            double z = (i & 4) == 0 ? -halfSize : halfSize;
            vertices[i][0] = x * cos - z * sin;
            vertices[i][1] = y;
            vertices[i][2] = x * sin + z * cos;
        }
        for (int i = 0; i < 8; i++) {
            for (int axis = 0; axis < 3; axis++) {
                if ((i & (1 << axis)) != 0) continue;
                int j = i | (1 << axis);
                for (int step = 0; step < steps; step++) {
                    double t = step / (double) (steps - 1);
                    double x = vertices[i][0] + (vertices[j][0] - vertices[i][0]) * t;
                    double y = vertices[i][1] + (vertices[j][1] - vertices[i][1]) * t;
                    double z = vertices[i][2] + (vertices[j][2] - vertices[i][2]) * t;
                    burst(sw, particle, cx + x, cy + y, cz + z, 1, 0, 0, 0, 0);
                }
            }
        }
    }

    /**
     * Draws a projected 4D hypercube (the classic tesseract shape): two cube frames,
     * eight connecting edges, and bright corner nodes. Unlike cubeOutline(), it has
     * sixteen vertices and thirty-two edges, so it reads as a tesseract instead of one cube.
     *
     * Keep pointsPerEdge low: these particles are deliberately sparse and the world-wide
     * particle budget remains in effect, even when several abilities overlap.
     */
    public static void tesseract(ServerLevel sw,
                                 ParticleOptions outerFrame,
                                 ParticleOptions innerFrame,
                                 ParticleOptions connectors,
                                 ParticleOptions corners,
                                 double cx, double cy, double cz,
                                 double halfSize, double phase, int pointsPerEdge) {
        int samples = Math.max(2, Math.min(pointsPerEdge, 4));
        double[][] projected = new double[16][3];
        double ax = phase * 0.91;
        double ay = phase * 0.73 + 0.37;
        double az = phase * 0.59;
        double cosX = Math.cos(ax), sinX = Math.sin(ax);
        double cosY = Math.cos(ay), sinY = Math.sin(ay);
        double cosZ = Math.cos(az), sinZ = Math.sin(az);
        double yaw = phase * 0.31;
        double pitch = phase * 0.22;
        double cosYaw = Math.cos(yaw), sinYaw = Math.sin(yaw);
        double cosPitch = Math.cos(pitch), sinPitch = Math.sin(pitch);

        for (int i = 0; i < 16; i++) {
            double x = (i & 1) == 0 ? -1.0 : 1.0;
            double y = (i & 2) == 0 ? -1.0 : 1.0;
            double z = (i & 4) == 0 ? -1.0 : 1.0;
            double w = (i & 8) == 0 ? -1.0 : 1.0;

            // Rotate in three planes that involve the fourth (W) dimension.
            double nx = x * cosX - w * sinX;
            w = x * sinX + w * cosX;
            x = nx;
            double ny = y * cosY - w * sinY;
            w = y * sinY + w * cosY;
            y = ny;
            double nz = z * cosZ - w * sinZ;
            w = z * sinZ + w * cosZ;
            z = nz;

            // Perspective projection makes one cube appear inside the other.
            double perspective = 1.0 / Math.max(0.8, 1.7 - w * 0.33);
            x *= halfSize * perspective;
            y *= halfSize * perspective;
            z *= halfSize * perspective;

            double rx = x * cosYaw - z * sinYaw;
            double rz = x * sinYaw + z * cosYaw;
            double ry = y * cosPitch - rz * sinPitch;
            rz = y * sinPitch + rz * cosPitch;
            projected[i][0] = rx;
            projected[i][1] = ry;
            projected[i][2] = rz;
        }

        // A 4D hypercube has 32 edges. Bit 3 is W, so those 8 edges bridge the two cubes.
        for (int i = 0; i < 16; i++) {
            for (int axis = 0; axis < 4; axis++) {
                int mask = 1 << axis;
                if ((i & mask) != 0) continue;
                int j = i | mask;
                ParticleOptions particle = axis == 3 ? connectors : ((i & 8) == 0 ? outerFrame : innerFrame);
                for (int sample = 0; sample < samples; sample++) {
                    double t = sample / (double) (samples - 1);
                    double x = projected[i][0] + (projected[j][0] - projected[i][0]) * t;
                    double y = projected[i][1] + (projected[j][1] - projected[i][1]) * t;
                    double z = projected[i][2] + (projected[j][2] - projected[i][2]) * t;
                    burst(sw, particle, cx + x, cy + y, cz + z, 1, 0, 0, 0, 0);
                }
            }
        }
        for (int i = 0; i < 16; i++) {
            burst(sw, corners, cx + projected[i][0], cy + projected[i][1], cz + projected[i][2],
                    1, 0, 0, 0, 0);
        }
    }

    /**
     * A readable, layered impact: core flash, sonic ring, colored shockwave rings,
     * and eight radial energy spokes. Terrain is intentionally untouched.
     */
    public static void epicImpact(ServerLevel sw, Vec3 center,
                                  ParticleOptions energy, ParticleOptions sparks,
                                  double radius, int color) {
        double x = center.x;
        double y = center.y;
        double z = center.z;
        double safeRadius = Math.max(2.0, Math.min(24.0, radius));

        burst(sw, ParticleTypes.EXPLOSION_EMITTER, x, y + 0.25, z, 1, 0, 0, 0, 0);
        burst(sw, ParticleTypes.FLASH, x, y + 0.5, z, 1, 0, 0, 0, 0);
        burst(sw, ParticleTypes.SONIC_BOOM, x, y + 0.3, z, 1, 0, 0, 0, 0);
        burst(sw, energy, x, y + 0.6, z, 24, 0.7, 0.45, 0.7, 0.13);
        burst(sw, sparks, x, y + 0.7, z, 24, 0.9, 0.65, 0.9, 0.22);
        ring(sw, energy, x, y + 0.15, z, safeRadius * 0.52, 18);
        ring(sw, sparks, x, y + 0.45, z, safeRadius, 18);
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2.0 * i / 8.0;
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            line(sw, (i & 1) == 0 ? energy : sparks,
                    x + dx * 0.8, y + 0.15, z + dz * 0.8,
                    x + dx * safeRadius * 1.18, y + 0.15 + (i % 3 - 1) * 0.45,
                    z + dz * safeRadius * 1.18, 4);
        }
        screen(sw, center, safeRadius * 3.0, 0.38f, 1.55f, 12, color);
    }

    public static void sound(ServerLevel sw, BlockPos pos, SoundEvent sound, float volume, float pitch) {
        sw.playSound(null, pos, sound, SoundSource.PLAYERS, volume, pitch);
    }

    /** Compatibility overload for sound events represented by registry holders. */
    public static void sound(ServerLevel sw, BlockPos pos, Holder<SoundEvent> sound, float volume, float pitch) {
        sw.playSound(null, pos, sound.value(), SoundSource.PLAYERS, volume, pitch);
    }

    /** Screen flash + camera shake for nearby players, rate-limited to avoid stacked visual noise. */
    public static void screen(ServerLevel sw, Vec3 pos, double radius, float flash, float shake, int duration, int color) {
        long tick = sw.getGameTime();
        synchronized (LAST_SCREEN_TICK) {
            // Prune old players occasionally so the map does not grow forever on long-running servers.
            if (tick % 200 == 0 && tick != lastScreenCleanupTick) {
                LAST_SCREEN_TICK.entrySet().removeIf(entry -> tick - entry.getValue() > 1200);
                lastScreenCleanupTick = tick;
            }
        }
        for (ServerPlayer player : sw.players()) {
            if (player.distanceToSqr(pos) >= radius * radius) continue;
            UUID id = player.getUUID();
            synchronized (LAST_SCREEN_TICK) {
                Long last = LAST_SCREEN_TICK.get(id);
                if (last != null && tick - last < 4) continue;
                LAST_SCREEN_TICK.put(id, tick);
            }
            LuckyBlockMod.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new FxPacket(flash, shake, duration, color));
        }
    }

    /** Run a command silently as the server (spawns/updates the laser display entities). */
    public static void cmd(ServerLevel sw, String command) {
        try {
            MinecraftServer server = sw.getServer();
            server.getCommands().getDispatcher().execute(command,
                    server.createCommandSourceStack().withLevel(sw).withSuppressedOutput());
        } catch (Exception ignored) {
            // Missing display entities during cleanup are harmless.
        }
    }
}
