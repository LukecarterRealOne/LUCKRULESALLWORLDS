package com.lucky.mod;

import net.minecraft.client.Minecraft;

/** Client-only entry point referenced lazily by OpenItemWishPacket. */
public final class ClientItemWish {
    private ClientItemWish() {}

    public static void open() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.setScreen(new ItemWishScreen());
        }
    }
}
