package com.lucky.mod;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LuckyBlockMod.MOD_ID, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ClientState.tick();
        Minecraft mc = Minecraft.getInstance();
        while (ClientModEvents.OPEN_MENU.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                mc.setScreen(new AbilityScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (ClientState.shakeTicks > 0) {
            float amp = ClientState.shakeAmp * ClientState.shakeTicks / ClientState.shakeMax;
            event.setYaw(event.getYaw() + (ClientState.RNG.nextFloat() - 0.5f) * 2f * amp);
            event.setPitch(event.getPitch() + (ClientState.RNG.nextFloat() - 0.5f) * 2f * amp);
            event.setRoll(event.getRoll() + (ClientState.RNG.nextFloat() - 0.5f) * 2f * amp);
        }
    }

    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post event) {
        if (ClientState.flash <= 0.01f) return;
        int a = (int) (Math.min(1f, ClientState.flash) * 200);
        int argb = (a << 24) | (ClientState.flashColor & 0xFFFFFF);
        event.getGuiGraphics().fill(0, 0, event.getWindow().getGuiScaledWidth(),
                event.getWindow().getGuiScaledHeight(), argb);
    }
}
